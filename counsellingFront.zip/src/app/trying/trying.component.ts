import { Component } from '@angular/core';

@Component({
  selector: 'app-trying',
  imports: [],
  templateUrl: './trying.component.html',
  styleUrl: './trying.component.scss'
})
export class TryingComponent {

  startTest() {
    // Logic to start the test
  }
  
}
