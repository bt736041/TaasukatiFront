import { Component, inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { QuestionsService } from '../Services/questions.service';
import { PartTestComponent } from './partTest/partTest.component';



@Component({
  selector: 'app-test',
  imports: [RouterModule],
  templateUrl: './test.component.html',
  styleUrl: './test.component.scss'
})
export class TestComponent {

  router = inject(Router)
  questionService = inject(QuestionsService)

  // questions = this.questionService.getQuestions()
  // parts = this.questionService.getParts()

  currentPart = 0

  constructor() {
    this.router.navigate(['test/introduction'])
  }



}
