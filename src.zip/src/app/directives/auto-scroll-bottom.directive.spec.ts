import { AutoScrollBottomDirective } from './auto-scroll-bottom.directive';

describe('AutoScrollBottomDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoScrollBottomDirective();
    expect(directive).toBeTruthy();
  });
});
