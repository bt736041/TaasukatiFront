import { Injectable } from '@angular/core';
//האם משהו הולך לגשת לזה מצד הלקוח? או רק באלגוריתם?
export class types_To_Subjects{

}

@Injectable({
  providedIn: 'root'
})
export class TypesToSubjectsService {

  constructor() { }
}
