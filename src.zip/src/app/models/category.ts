export interface Category{
    id:number,
    name:string,
    description_simple:string,
    description_ai:string
}