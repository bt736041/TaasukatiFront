export interface IpConfig{
    serverUrl?:string
}