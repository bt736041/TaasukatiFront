export interface SettingsConfig{
    type_test?:string
}