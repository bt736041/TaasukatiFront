import { GetErrorPipe } from './get-error.pipe';

describe('GetErrorPipe', () => {
  it('create an instance', () => {
    const pipe = new GetErrorPipe();
    expect(pipe).toBeTruthy();
  });
});
