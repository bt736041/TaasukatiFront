import { Component } from '@angular/core';

@Component({
  selector: 'app-end-test-page',
  imports: [],
  templateUrl: './end-test-page.component.html',
  styleUrl: './end-test-page.component.scss'
})
export class EndTestPageComponent {
  goToResults() { }
}
